import myMath

print(myMath.penambahan(10, 5))
print(myMath.pengurangan(5, 2))
print(myMath.pembagian(10, 0))
print(myMath.perkalian(10, 5))
print(myMath.fibonacci(5))
print(myMath.modulus(10,5))
